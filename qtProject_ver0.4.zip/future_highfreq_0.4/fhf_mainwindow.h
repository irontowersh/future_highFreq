﻿#ifndef FHF_MAINWINDOW_H
#define FHF_MAINWINDOW_H

#include <QMainWindow>
#include <workthread.h>
#include <chartthread.h>
#include <QLabel>
#include <QHash>
#include <QTreeWidgetItem>
#include <QTreeWidget>
#include <QTimer>
#include <QtMath>

#include <QtCharts>
using namespace QtCharts;
#include <QBarSet>

namespace Ui {
class fhf_mainWindow;
}

class fhf_mainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit fhf_mainWindow(QWidget *parent = nullptr);
    ~fhf_mainWindow();
    QLabel *label_connect;
    QLabel *label_freq;
    QLabel *label_tableLen;


private slots:
    void testOnly(QTreeWidgetItem *, QTreeWidgetItem *);
    void testOnly();

    void initStyle();
    void on_btnConnect_clicked();
    void onConnectFinished();

    void on_btnContracts_clicked();
    void onQueryContractFinished();
    void onItemDoubleClicked(QTreeWidgetItem *item, int column);

    void on_btnQuery_clicked();
    void on_queryTableProgress(int, int);
    void on_queryTableFinished();
    void on_tcpTimeout();
    void on_refreshTimeout();

    void on_btnFile_clicked();
    void on_plottingChartFinished();

    void on_comboBox_dataItem_currentTextChanged(const QString &arg1);
    void on_comboBox_dayNight_currentTextChanged(const QString &arg1);

    void plotChartMinute();
    void plotChartPie();
    void plotChartHistogram();

    void on_pushButton_chart1_clicked();
    void on_pushButton_chart2_clicked();

private:
    Ui::fhf_mainWindow *ui;
    WorkThread * pWorkThread;
    ChartThread * pChartThread;
    QTreeWidgetItem *item;
    QMultiHash<QString,QString> *m_contractHash;
    quint64 bytesToSend=0;
    QTimer *m_timerTcp;
    QTimer *m_timerRefresh;
    void initTree();
    void set_buttons_disconnected();
    void set_buttons_connecting();
    void set_buttons_connected();
    void set_buttons_queryingContracts();
    void set_buttons_queryFinished();
    void set_buttons_queryingTable();
    void set_ChartInvisible();
    void set_ChartVisible();

    QChart *chartHistogram,*chartMinute,*chartPie;
    void exportChartMinute();
    void exportChartPie();
    bool flag_readyForTextChanged=false;

    void adjust_windowGeometry();

protected:
    void closeEvent(QCloseEvent*event);

signals:
    void signalChart(QString,QString,QString);
    void signalClearBar();
    void signalClearTick();
};

#endif // FHF_MAINWINDOW_H
