﻿#include "workthread.h"
#include <QDebug>


WorkThread::WorkThread(QTableWidget *table)
{
    pTable=table;
    qDebug()<<pTable;

    qRegisterMetaType<bar_struct>("bar_struct");
    qRegisterMetaType<tick_struct>("tick_struct");
    qDebug()<<&m_mutex;
}

void WorkThread::run()
{
    while (true) {
        msleep(10);

        if (status==status_connecting) {
            connectToServer();
        }

        else if (status==status_queryingContracts) {
            queryContractList();
        }

        else if (status==status_queryingTable) {
            //qDebug()<<"status==status_queryingTable";
            //读取Tcp数据
            while (bytesAvailable>0) {
                if (freqStr=="1 min"){
                    bar_struct barData;
                    generateBar(barData);
                    barQueue.enqueue(barData);
                    int positionChange = barData.position - last_postition;
                    last_postition = barData.position;
                    emit signalBar(
                        barData.datetime,barData.volume,positionChange
                    );
                    //qDebug()<<"barQueue increased:"<<barQueue.count()-len;
                } else if (freqStr=="tick") {
                    tick_struct tickData;
                    generateTick(tickData);
                    tickQueue.enqueue(tickData);
                    int positionChange = tickData.position - last_postition;
                    last_postition = tickData.position;
                    emit signalTick(
                        tickData.datetime,tickData.price,tickData.last_volume,
                        positionChange,tickData.bid1_vol,tickData.ask1_vol
                    );

                    //qDebug()<<"tickQueue increased:"<<tickQueue.count()-len;
                } else {
                    throw ("the param of frequency is invalid, while running 'WorkThread::status_queryingTable'");
                }
                bytesRemaining-=1;
                bytesAvailable-=1;

                num_gen+=1;
            }

            //写入GUI界面的TableWidget
            if (flagRefresh) {
                flagRefresh=false;

                m_mutex.tryLock();//锁定GUI界面TableWidget
                if (freqStr=="1 min"){
                    while (barQueue.count()>0) {
                        bar_struct bar;
                        bar=barQueue.head();
                        barQueue.pop_front();
                        //qDebug()<<"barQueue Count:"<<barQueue.count()<<"; Bytes remains"<<bytesRemaining;
                        addBarToTable(bar);
                    }
                } else if (freqStr=="tick") {
                    while (tickQueue.count()>0) {
                        tick_struct tick;
                        tick=tickQueue.head();
                        tickQueue.pop_front();
                        //qDebug()<<"tickQueue Count:"<<tickQueue.count()<<"; Bytes remains"<<bytesRemaining;
                        addTickToTable(tick);
                    }
                } else {
                    throw ("the param of frequency is invalid, while running 'WorkThread::status_queryingTable-refresh'");
                }
                int total=int(bytesTotal);
                if (pTable->rowCount()>=total*(progressPercent+1)/100) {
                    progressPercent=quint16(floor(100.0*pTable->rowCount()/(total)));
                    //qDebug()<<pTable->rowCount()<<total*(progressPercent+1)/100;
                    emit queryTableProgress(pTable->rowCount(), total);
                }
                m_mutex.unlock();//解锁

                if ((bytesRemaining==0) || (bytesRemaining>1.0e+012)) {
                    progressPercent=0;
                    status=status_queryFinished;
                    emit queryTableFinished();

                    num_gen=0;
                    last_postition=100000;
                }
            }

        }

    }
}


void WorkThread::set_bytesTotal(quint64 n)
{
    bytesTotal=n;
}

void WorkThread::set_bytesRemaining(quint64 n)
{
    bytesRemaining=n;
}

//连接服务器
void WorkThread::connectToServer()
{
    sleep(1);
    //qDebug()<<QStringLiteral("服务器已连接");
    status=status_connected;
    emit connectFinished();
}

//查询期货合约列表
void WorkThread::queryContractList()
{
    QStringList symbolStrList;
    QStringList monthStrList;
    monthStrList<<"2001"<<"2003"<<"2005"<<"2007"<<"2009"<<"2011";

    if (freqStr=="1 min") {
       sleep(3);
       symbolStrList<<"aa"<<"bb"<<"cc"<<"dd"<<"ee";
    } else if (freqStr=="tick") {
       sleep(3);
       symbolStrList<<"v"<<"w"<<"x"<<"y"<<"z";
    } else {
       throw("the param of frequency is invalid, while running 'WorkThread::queryContractList()' ");
    }

    ContractList.clear();
    for (quint16 i=0; i<symbolStrList.count();i++)
        for (quint16 j=0; j<monthStrList.count();j++)
            ContractList.append(symbolStrList.at(i)+monthStrList.at(j));
    qDebug()<<ContractList;

    status=status_queryFinished;
    emit queryContractFinished();
}

void WorkThread::addBarToTable(bar_struct bar)
{
    //qDebug()<<bar.datetime.toString(Qt::ISODate)<<bar.open<<bar.high<<bar.low<<bar.close;
    int rowNum=pTable->rowCount();
    pTable->setRowCount(rowNum+1);

    QTableWidgetItem *item;
    QString itemStr;

    itemStr=bar.datetime.toString("yyyy-MM-dd hh:mm:ss.zzz");
    item=new QTableWidgetItem(itemStr,0);
    item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
    item->setData(Qt::DisplayRole,itemStr);
    pTable->setItem(rowNum,0,item);

    itemStr=QString::number(bar.open);
    item=new QTableWidgetItem(itemStr,0);
    item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
    item->setData(Qt::DisplayRole,itemStr);
    pTable->setItem(rowNum,1,item);

    itemStr=QString::number(bar.high);
    item=new QTableWidgetItem(itemStr,0);
    item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
    item->setData(Qt::DisplayRole,itemStr);
    pTable->setItem(rowNum,2,item);

    itemStr=QString::number(bar.low);
    item=new QTableWidgetItem(itemStr,0);
    item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
    item->setData(Qt::DisplayRole,itemStr);
    pTable->setItem(rowNum,3,item);

    itemStr=QString::number(bar.close);
    item=new QTableWidgetItem(itemStr,0);
    item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
    item->setData(Qt::DisplayRole,itemStr);
    pTable->setItem(rowNum,4,item);

    itemStr=QString::number(bar.volume);
    item=new QTableWidgetItem(itemStr,0);
    item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
    item->setData(Qt::DisplayRole,itemStr);
    pTable->setItem(rowNum,5,item);

    itemStr=QString::number(bar.amount);
    item=new QTableWidgetItem(itemStr,0);
    item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
    item->setData(Qt::DisplayRole,itemStr);
    pTable->setItem(rowNum,6,item);

    itemStr=QString::number(bar.position);
    item=new QTableWidgetItem(itemStr,0);
    item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
    item->setData(Qt::DisplayRole,itemStr);
    pTable->setItem(rowNum,7,item);

    //qDebug()<<"rowCount = "<<pTable->rowCount();
}

void WorkThread::addTickToTable(tick_struct tick)
{
    //qDebug()<<tick.datetime.toString(Qt::ISODate)<<tick.bid1<<tick.bid1_vol<<tick.ask1<<tick.ask1_vol;
    int rowNum=pTable->rowCount();
    pTable->setRowCount(rowNum+1);

    QTableWidgetItem *item;
    QString itemStr;

    itemStr=tick.datetime.toString("yyyy-MM-dd hh:mm:ss.zzz");
    item=new QTableWidgetItem(itemStr,0);
    item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
    item->setData(Qt::DisplayRole,itemStr);
    pTable->setItem(rowNum,0,item);

    itemStr=QString::number(tick.price);
    item=new QTableWidgetItem(itemStr,0);
    item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
    item->setData(Qt::DisplayRole,itemStr);
    pTable->setItem(rowNum,1,item);

    itemStr=QString::number(tick.last_volume);
    item=new QTableWidgetItem(itemStr,0);
    item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
    item->setData(Qt::DisplayRole,itemStr);
    pTable->setItem(rowNum,2,item);

    itemStr=QString::number(tick.last_amount);
    item=new QTableWidgetItem(itemStr,0);
    item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
    item->setData(Qt::DisplayRole,itemStr);
    pTable->setItem(rowNum,3,item);

    itemStr=QString::number(tick.bid1);
    item=new QTableWidgetItem(itemStr,0);
    item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
    item->setData(Qt::DisplayRole,itemStr);
    pTable->setItem(rowNum,4,item);

    itemStr=QString::number(tick.bid1_vol);
    item=new QTableWidgetItem(itemStr,0);
    item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
    item->setData(Qt::DisplayRole,itemStr);
    pTable->setItem(rowNum,5,item);

    itemStr=QString::number(tick.ask1);
    item=new QTableWidgetItem(itemStr,0);
    item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
    item->setData(Qt::DisplayRole,itemStr);
    pTable->setItem(rowNum,6,item);

    itemStr=QString::number(tick.ask1_vol);
    item=new QTableWidgetItem(itemStr,0);
    item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
    item->setData(Qt::DisplayRole,itemStr);
    pTable->setItem(rowNum,7,item);

    itemStr=QString::number(tick.position);
    item=new QTableWidgetItem(itemStr,0);
    item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
    item->setData(Qt::DisplayRole,itemStr);
    pTable->setItem(rowNum,8,item);

    itemStr=QString::number(tick.openD);
    item=new QTableWidgetItem(itemStr,0);
    item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
    item->setData(Qt::DisplayRole,itemStr);
    pTable->setItem(rowNum,9,item);

    itemStr=QString::number(tick.highD);
    item=new QTableWidgetItem(itemStr,0);
    item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
    item->setData(Qt::DisplayRole,itemStr);
    pTable->setItem(rowNum,10,item);

    itemStr=QString::number(tick.lowD);
    item=new QTableWidgetItem(itemStr,0);
    item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
    item->setData(Qt::DisplayRole,itemStr);
    pTable->setItem(rowNum,11,item);

    //qDebug()<<"rowCount = "<<pTable->rowCount();
}

void WorkThread::generateBar(bar_struct &barData)
{

    barData.datetime=QDateTime::currentDateTime().addSecs(60*num_gen);
    barData.open=4000.0;
    barData.high=4005.5;
    barData.low=3995.5;
    barData.close=4001.0;

    int msec= QTime::currentTime().msec();
    int num1=msec % 50;
    int num2=7*msec % (num1+1);
    barData.volume= 2*num1;
    int position_change=2*num2*((num_gen%2)*2-1);
    barData.position=last_postition+position_change;
    barData.amount=barData.close*barData.volume;
}

void WorkThread::generateTick(tick_struct &tickData)
{
    int msec= QTime::currentTime().msec();
    tickData.datetime=QDateTime::currentDateTime().addSecs(num_gen);
    tickData.bid1=2999.5;
    tickData.bid1_vol=msec%15;
    tickData.ask1=3001.0;
    tickData.ask1_vol=(msec+10)%15;
    tickData.price=3000.0;

    int num1=msec % 50;
    int num2=7*msec % (num1+1);
    tickData.last_volume= 2*num1;
    int position_change=2*num2*((num_gen%2)*2-1);
    tickData.position=last_postition+position_change;
    tickData.last_amount=tickData.price*tickData.last_volume;
    tickData.openD=9999.0;
    tickData.highD=9999.0;
    tickData.lowD=9999.0;
}
