﻿#ifndef DATA_STRUCT_H
#define DATA_STRUCT_H

#include <QDateTime>
#include <QMetaType>

typedef struct {
    QDateTime datetime;
    qreal open;
    qreal high;
    qreal low;
    qreal close;
    int volume;
    qreal amount;
    int position;
} bar_struct;
Q_DECLARE_METATYPE(bar_struct);

typedef struct {
    QDateTime datetime;
    qreal price;
    int last_volume;
    qreal last_amount;
    qreal bid1;
    int bid1_vol;
    qreal ask1;
    int ask1_vol;
    int position;
    qreal openD;
    qreal highD;
    qreal lowD;
} tick_struct;
Q_DECLARE_METATYPE(tick_struct);

#endif // DATA_STRUCT_H
