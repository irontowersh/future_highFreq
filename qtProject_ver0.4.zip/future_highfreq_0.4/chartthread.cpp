﻿#include "chartthread.h"
#include <QDebug>
#include <QtMath>
#include <cmath>

ChartThread::ChartThread(QChartView *chart1, QChartView *chart2)
{
    pChart1 = chart1;
    pChart2 = chart2;

    tradeTypeNames
    <<QStringLiteral("双开")
    <<QStringLiteral("双平")
    <<QStringLiteral("多开")
    <<QStringLiteral("空开")
    <<QStringLiteral("空平")
    <<QStringLiteral("多平")
    <<QStringLiteral("多换")
    <<QStringLiteral("空换");
}

void ChartThread::run()
{
    while (true) {
        if (status==status_plotting) {
            status=status_loading;
            //依次执行
            setCurrentData();
            calculateSatistics();
            plotChart1();
            plotChart2();
            //测试打印
            qDebug()
            <<"Plotting Chart finished!"
            <<barListDay_volume.count()
            <<barListNight_volume.count()
            <<tickListDay_volume.count()
            <<tickListNight_volume.count();
            emit plottingChartFinished();
        }
        msleep(50);
    }
}



void ChartThread::setStatusPlotting(QString str1,QString str2, QString str3)
{
    freq=str1;
    dataItem=str2;
    dayNight=str3;
    status=status_plotting;
}

void ChartThread::clearTick()
{
    tickListDay_ask1Vol.clear();
    tickListDay_bid1Vol.clear();
    tickListDay_positionChange.clear();
    tickListDay_tradeType.clear();
    tickListDay_volume.clear();
    tickListNight_ask1Vol.clear();
    tickListNight_bid1Vol.clear();
    tickListNight_positionChange.clear();
    tickListNight_tradeType.clear();
    tickListNight_volume.clear();
}

void ChartThread::clearBar()
{
    barListDay_positionChange.clear();
    barListDay_volume.clear();
    barListNight_positionChange.clear();
    barListNight_volume.clear();

    barHashDay_keys.clear();
    barHashDay_positionChange.clear();
    barHashDay_volume.clear();
    barHashNight_keys.clear();
    barHashNight_positionChange.clear();
    barHashNight_volume.clear();

    for (quint16 i=0; i<24; i++)
        for (quint16 j=0; j<60; j++) {
            QString hh,mm;
            if (i<10)
                hh="0"+QString::number(i);
            else
                hh=QString::number(i);
            if (j<10)
                mm="0"+QString::number(j);
            else
                mm=QString::number(j);
            QString hh_mm=hh+":"+mm;
            if (hh_mm>="08:00" && hh_mm<"20:00") {
                barHashDay_keys.insert(hh_mm,0);
            } else {
                barHashNight_keys.insert(hh_mm,0);
            }
        }
}


void ChartThread::processTick(QDateTime dt,qreal price,int volume, int positionChange, int bid1Vol, int ask1Vol)
{
    QString hhmmss=dt.toString("hh:mm:ss");

    if (hhmmss>="08:00:00" && hhmmss<"20:00:00") {
        tickListDay_volume.append(volume);
        tickListDay_positionChange.append(positionChange);
        tickListDay_bid1Vol.append(bid1Vol);
        tickListDay_ask1Vol.append(ask1Vol);
        if (positionChange>0 && positionChange==volume)
            tickListDay_tradeType.append(tradeType_shuangKai);
        else if (positionChange<0 && positionChange==-1*volume)
            tickListDay_tradeType.append(tradeType_shuangPing);
        else if (positionChange>0 && positionChange<volume &&
                 (price>last_tickPrice || (price>last_tickPrice-0.0001 && price>last_tickPrice2)))
            tickListDay_tradeType.append(tradeType_duoKai);
        else if (positionChange>0 && positionChange<volume &&
                 (price<last_tickPrice || (price<last_tickPrice+0.0001 && price<last_tickPrice2)))
            tickListDay_tradeType.append(tradeType_kongKai);
        else if (positionChange<0 && positionChange>-1*volume &&
                 (price>last_tickPrice || (price>last_tickPrice-0.0001 && price>last_tickPrice2)))
            tickListDay_tradeType.append(tradeType_kongPing);
        else if (positionChange<0 && positionChange>-1*volume &&
                 (price<last_tickPrice || (price<last_tickPrice+0.0001 && price<last_tickPrice2)))
            tickListDay_tradeType.append(tradeType_duoPing);
        else if (positionChange==0 && (price>last_tickPrice || (price>last_tickPrice-0.0001 && price>last_tickPrice2)))
            tickListDay_tradeType.append(tradeType_duoHuan);
        else if (positionChange==0 && (price<last_tickPrice || (price<last_tickPrice+0.0001 && price<last_tickPrice2)))
            tickListDay_tradeType.append(tradeType_kongHuan);
        else
            throw("Error occurs when defining tick_tradeType");
    }
    else if (hhmmss>="20:00:00" || hhmmss<"08:00:00") {
        tickListNight_volume.append(volume);
        tickListNight_positionChange.append(positionChange);
        tickListNight_bid1Vol.append(bid1Vol);
        tickListNight_ask1Vol.append(ask1Vol);
        if (positionChange>0 && positionChange==volume)
            tickListNight_tradeType.append(tradeType_shuangKai);
        else if (positionChange<0 && positionChange==-1*volume)
            tickListNight_tradeType.append(tradeType_shuangPing);
        else if (positionChange>0 && positionChange<volume &&
                 (price>last_tickPrice || (price>last_tickPrice-0.0001 && price>last_tickPrice2)))
            tickListNight_tradeType.append(tradeType_duoKai);
        else if (positionChange>0 && positionChange<volume &&
                 (price<last_tickPrice || (price<last_tickPrice+0.0001 && price<last_tickPrice2)))
            tickListNight_tradeType.append(tradeType_kongKai);
        else if (positionChange<0 && positionChange>-1*volume &&
                 (price>last_tickPrice || (price>last_tickPrice-0.0001 && price>last_tickPrice2)))
            tickListNight_tradeType.append(tradeType_kongPing);
        else if (positionChange<0 && positionChange>-1*volume &&
                 (price<last_tickPrice || (price<last_tickPrice+0.0001 && price<last_tickPrice2)))
            tickListNight_tradeType.append(tradeType_duoPing);
        else if (positionChange==0 && (price>last_tickPrice || (price>last_tickPrice-0.0001 && price>last_tickPrice2)))
            tickListNight_tradeType.append(tradeType_duoHuan);
        else if (positionChange==0 && (price<last_tickPrice || (price<last_tickPrice+0.0001 && price<last_tickPrice2)))
            tickListNight_tradeType.append(tradeType_kongHuan);
        else
            throw("Error occurs when defining tick_tradeType");
    }
    //保留最新两个tick价格数据
    if (price>last_tickPrice+0.0001 || price<last_tickPrice-0.0001) {
        last_tickPrice2 = last_tickPrice;
        last_tickPrice = price;
    }

    //qDebug()<<tickListDay_volume.count()<<tickListNight_volume.count();
}

void ChartThread::processBar(QDateTime dt ,int volume,int positionChange)
{
    QString hhmmss=dt.toString("hh:mm:ss");
    QString hh_mm = dt.toString("hh:mm");

    if (hhmmss>="08:00:00" && hhmmss<"20:00:00") {
        barListDay_volume.append(volume);
        barListDay_positionChange.append(positionChange);
        if (barHashDay_keys[hh_mm]>0) {
            barHashDay_volume[hh_mm]+=volume;
            barHashDay_positionChange[hh_mm]+=positionChange;
        } else {
            barHashDay_volume.insert(hh_mm,volume);
            barHashDay_positionChange.insert(hh_mm,positionChange);
        }
        barHashDay_keys[hh_mm]+=1;
    }
    else if (hhmmss>="20:00:00" || hhmmss<"08:00:00") {
        barListNight_volume.append(volume);
        barListNight_positionChange.append(positionChange);
        if (barHashNight_keys[hh_mm]>0) {
            barHashNight_volume[hh_mm]+=volume;
            barHashNight_positionChange[hh_mm]+=positionChange;
        } else {
            barHashNight_volume.insert(hh_mm,volume);
            barHashNight_positionChange.insert(hh_mm,positionChange);
        }
        barHashNight_keys[hh_mm]+=1;
    }

    //qDebug()<<barListDay_volume.count()<<barListNight_volume.count()<<barHashDay_keys["18:00"];
}


void ChartThread::setCurrentData()
{
    //bar模式
    if (freq=="1 min") {
        if (dataItem=="volume") {
            if (dayNight==QStringLiteral("仅日盘")) {
                currentDataList=barListDay_volume;
                currentBarHash=barHashDay_volume;
                currrentBarKeyHash=barHashDay_keys;
            }
            else if (dayNight==QStringLiteral("仅夜盘")) {
                currentDataList=barListNight_volume;
                currentBarHash=barHashNight_volume;
                currrentBarKeyHash=barHashNight_keys;
            }
            else {
                currentDataList=barListDay_volume;
                currentDataList.append(barListNight_volume);
                currentBarHash=barHashDay_volume;
                currentBarHash.unite(barHashNight_volume);
                currrentBarKeyHash=barHashDay_keys;
                currrentBarKeyHash.unite(barHashNight_keys);
            }
        } else if (dataItem=="pos_change") {
            if (dayNight==QStringLiteral("仅日盘")) {
                currentDataList=barListDay_positionChange;
                currentBarHash=barHashDay_positionChange;
                currrentBarKeyHash=barHashDay_keys;
            }
            else if (dayNight==QStringLiteral("仅夜盘")) {
                currentDataList=barListNight_positionChange;
                currentBarHash=barHashNight_positionChange;
                currrentBarKeyHash=barHashNight_keys;
            }
            else {
                currentDataList=barListDay_positionChange;
                currentDataList.append(barListNight_positionChange);
                currentBarHash=barHashDay_positionChange;
                currentBarHash.unite(barHashNight_positionChange);
                currrentBarKeyHash=barHashDay_keys;
                currrentBarKeyHash.unite(barHashNight_keys);
            }
        }
    }

    //tick模式
    else {
        if (dataItem=="last_volume") {
            if (dayNight==QStringLiteral("仅日盘"))
                currentDataList=tickListDay_volume;
            else if (dayNight==QStringLiteral("仅夜盘"))
                currentDataList=tickListNight_volume;
            else {
                currentDataList=tickListDay_volume;
                currentDataList.append(tickListNight_volume);
            }
        } else if (dataItem=="pos_change") {
            if (dayNight==QStringLiteral("仅日盘"))
                currentDataList=tickListDay_positionChange;
            else if (dayNight==QStringLiteral("仅夜盘"))
                currentDataList=tickListNight_positionChange;
            else {
                currentDataList=tickListDay_positionChange;
                currentDataList.append(tickListNight_positionChange);
            }
        } else if (dataItem=="bid1_vol") {
            if (dayNight==QStringLiteral("仅日盘"))
                currentDataList=tickListDay_bid1Vol;
            else if (dayNight==QStringLiteral("仅夜盘"))
                currentDataList=tickListNight_bid1Vol;
            else {
                currentDataList=tickListDay_bid1Vol;
                currentDataList.append(tickListNight_bid1Vol);
            }
        } else if (dataItem=="ask1_vol") {
            if (dayNight==QStringLiteral("仅日盘"))
                currentDataList=tickListDay_ask1Vol;
            else if (dayNight==QStringLiteral("仅夜盘"))
                currentDataList=tickListNight_ask1Vol;
            else {
                currentDataList=tickListDay_ask1Vol;
                currentDataList.append(tickListNight_ask1Vol);
            }
        }
    }
    std::sort(currentDataList.begin(),currentDataList.end());

    qDebug()<<"setCurrentData Finishend:"<<freq<<dataItem<<dayNight<<currentDataList.count();
}


void ChartThread::calculateSatistics()
{
    qreal sumValue=0,avgValue=0,sumStd=0,stdValue=0;
    int length=currentDataList.count();

    if (length>0) {

        for (int i=0;i<currentDataList.count();i++)
            sumValue+=currentDataList.at(i);
        avgValue=sumValue/currentDataList.count();

        for (int j=0;j<currentDataList.count();j++)
            sumStd += qPow(currentDataList.at(j)-avgValue,2);
        stdValue=qSqrt(sumStd/length);

        str_mean=QString::number(avgValue);
        str_std=QString::number(stdValue);

        str_d25=QString::number(currentDataList.at(int(0.25*length)-1));
        str_d50=QString::number(currentDataList.at(int(0.50*length)-1));
        str_d75=QString::number(currentDataList.at(int(0.75*length)-1));
        str_d90=QString::number(currentDataList.at(int(0.90*length)-1));
        str_d95=QString::number(currentDataList.at(int(0.95*length)-1));
        str_medium=str_d50;

    } else {
        str_mean="nan";
        str_std="nan";
        str_d25="nan";
        str_d50="nan";
        str_d75="nan";
        str_d90="nan";
        str_d95="nan";
        str_medium=str_d50;
    }
    qDebug()<<"Caculate statistic finished";
}


void ChartThread::plotChart1()
{
    if (!currentDataList.isEmpty()) {
        qreal minMax=currentDataList.last()-currentDataList.first();
        qreal ep=log10(minMax);
        qreal interval=pow(10,int(floor(ep))-1);
        bool flag= int(interval)==1 && (dataItem=="volume" || dataItem=="last_volume" || dataItem=="pos_change");
        if (flag) interval = 2;

        qreal minX=floor(currentDataList.first()/interval)*interval;
        //qreal maxX=ceil(currentDataList.last()/interval)*interval;

        chartHistogram_xAxis.clear();
        chartHistogram_yAxis.clear();
        qreal under=minX;
        qreal upper=under+interval;
        chartHistogram_xAxis.append(
            QString("[%1 ~ %2)")
            .arg(QString::number(under))
            .arg(QString::number(upper))
        );
        chartHistogram_yAxis.append(0);
        //qDebug()<<chartHistogram_xAxis.first();

        int i=0;
        while (i<currentDataList.count()) {
            if (currentDataList.at(i)>=under && currentDataList.at(i)<upper){
                chartHistogram_yAxis.last()+=1;
            } else {
                under=upper;
                upper=under+interval;
                QString xLabel;
                xLabel=QString("[%1 ~ %2)").arg(QString::number(under)).arg(QString::number(upper));
                chartHistogram_xAxis.append(xLabel);
                chartHistogram_yAxis.append(0);
            }
            i+=1;
        }
        //qDebug()<<chartHistogram_yAxis;
    }
    qDebug()<<"plotChart1 finished, freq:"<<freq;

    emit chartHistogramReady();
}


void ChartThread::plotChart2()
{
    if (freq=="1 min") {
        plotChartMinute();
    } else {
        plotChartPie();
    }
    qDebug()<<"plotChart2 finished, freq:"<<freq;
}

void ChartThread::plotChartMinute()
{
    chartMinute_xAxis.clear();
    chartMinute_yAxis.clear();

    chartMinute_xAxis=currrentBarKeyHash.keys();
    std::sort(chartMinute_xAxis.begin(),chartMinute_xAxis.end());
    //qDebug()<<chartMinute_xAxis<<dataItem;
    for (int i=0;i<chartMinute_xAxis.count();i++) {
        QString key=chartMinute_xAxis.at(i);
        if (currrentBarKeyHash[key]>0) {
            chartMinute_yAxis.append(currentBarHash[key]*1.0/currrentBarKeyHash[key]);
        } else {
            chartMinute_yAxis.append(0.0);
        }
    }
    qDebug()<<"chartMinute_axis count:"<<chartMinute_xAxis.count();

    emit chartMinuteReady();
}

void ChartThread::plotChartPie()
{
    if (dayNight==QStringLiteral("仅日盘"))
        tradeTypeList=tickListDay_tradeType;
    else if (dayNight==QStringLiteral("仅夜盘"))
        tradeTypeList=tickListNight_tradeType;
    else {
        tradeTypeList=tickListDay_tradeType;
        tradeTypeList.append(tickListNight_tradeType);
    }

    tradeTypeCounts.clear();
    for (quint16 i=0; i<8; i++) {
        tradeTypeEnum temp=tradeTypeEnum(i);
        int countNum = tradeTypeList.count(temp);
        tradeTypeCounts.append(countNum);
    }
    qDebug()<<"tradeType count:"<<tradeTypeCounts;

    emit chartPieReady();
}
