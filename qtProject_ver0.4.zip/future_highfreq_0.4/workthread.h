﻿#ifndef WORKTHREAD_H
#define WORKTHREAD_H

#include <QObject>
#include <QThread>
#include <QStringList>
#include "data_struct.h"
#include <QQueue>
#include <QDateTime>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QMetaType>
#include <QMutex>

class WorkThread : public QThread
{
    Q_OBJECT

public:
    WorkThread(QTableWidget *table);
    QTableWidget *pTable=nullptr;

    enum statusStage{
        status_disconnected=1000,
        status_connecting,status_connected,
        status_queryingContracts,
        status_queryFinished,
        status_queryingTable
    };
    statusStage status=status_disconnected;

    QString freqStr;
    QStringList ContractList;

    QString curContract=QStringLiteral("未选择");
    quint16 bytesAvailable=0;
    QQueue<bar_struct> barQueue;
    QQueue<tick_struct> tickQueue;
    bool flagRefresh=false;
    quint16 progressPercent=0;
    void set_bytesTotal(quint64);
    void set_bytesRemaining(quint64);

private:
    QMutex m_mutex;
    void connectToServer();
    void queryContractList();

    void addBarToTable(bar_struct);
    void addTickToTable(tick_struct);

    quint64 bytesTotal=0;
    quint64 bytesRemaining=0;
    void generateBar(bar_struct &);
    void generateTick(tick_struct &);
    int num_gen=0;
    int last_postition=100000;

public slots:
    void run();


signals:
    void connectFinished();
    void queryContractFinished();
    void queryTableFinished();
    void queryTableProgress(int, int);

    void signalBar(QDateTime,int,int);
    void signalTick(QDateTime,qreal,int,int,int,int);
};


#endif // WORKTHREAD_H
