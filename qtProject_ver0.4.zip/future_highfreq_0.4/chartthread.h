﻿#ifndef CHARTTHREAD_H
#define CHARTTHREAD_H

#include <QObject>
#include <QThread>
#include <QHash>
#include <QDateTime>

#include <QtCharts>
using namespace QtCharts;

class ChartThread : public QThread
{
    Q_OBJECT

public:
    ChartThread(
        QChartView *chart1,
        QChartView *chart2
    );
    enum tradeTypeEnum{
        tradeType_shuangKai=1,
        tradeType_shuangPing,
        tradeType_duoKai,
        tradeType_kongKai,
        tradeType_kongPing,
        tradeType_duoPing,
        tradeType_duoHuan,
        tradeType_kongHuan
    };
    enum status_stage{
        status_loading=1000,
        status_plotting
    };
    status_stage status=status_loading;
    void run();

    QString str_mean;
    QString str_std;
    QString str_medium;
    QString str_d25;
    QString str_d50;
    QString str_d75;
    QString str_d90;
    QString str_d95;

    QStringList tradeTypeNames;
    QList<int> tradeTypeCounts;
    QList<tradeTypeEnum> tradeTypeList;

    QStringList chartMinute_xAxis;
    QList<qreal> chartMinute_yAxis;

    QStringList chartHistogram_xAxis;
    QList<int> chartHistogram_yAxis;


signals:
    void plottingChartFinished();
    void chartPieReady();
    void chartMinuteReady();
    void chartHistogramReady();

public slots:
    void processBar(QDateTime,int,int);
    void processTick(QDateTime,qreal,int,int,int,int);
    void setStatusPlotting(QString,QString,QString);
    void clearTick();
    void clearBar();


private:
    QChartView *pChart1,*pChart2;

    QHash<QString,int> barHashDay_keys;
    QList<int> barListDay_volume;
    QList<int> barListDay_positionChange;
    QHash<QString,int> barHashDay_volume;
    QHash<QString,int> barHashDay_positionChange;

    QHash<QString,int> barHashNight_keys;
    QList<int> barListNight_volume;
    QList<int> barListNight_positionChange;
    QHash<QString,int> barHashNight_volume;
    QHash<QString,int> barHashNight_positionChange;

    QList<int> tickListDay_volume;
    QList<int> tickListDay_positionChange;
    QList<int> tickListDay_bid1Vol;
    QList<int> tickListDay_ask1Vol;
    QList<tradeTypeEnum> tickListDay_tradeType;
    QList<int> tickListNight_volume;
    QList<int> tickListNight_positionChange;
    QList<int> tickListNight_bid1Vol;
    QList<int> tickListNight_ask1Vol;
    QList<tradeTypeEnum> tickListNight_tradeType;
    qreal last_tickPrice=0;
    qreal last_tickPrice2=0;

    QString freq;
    QString dataItem;
    QString dayNight;
    QList<int> currentDataList;
    QHash<QString,int> currentBarHash;
    QHash<QString,int> currrentBarKeyHash;

    void setCurrentData();
    void calculateSatistics();
    void plotChart1();
    void plotChart2();

    void plotChartMinute();
    void plotChartPie();



};

#endif // CHARTTHREAD_H
