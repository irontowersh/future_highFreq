﻿#include "fhf_mainwindow.h"
#include "ui_fhf_mainwindow.h"
#include <QLabel>
#include <QStandardItemModel>
#include <QDebug>
#include <QStyle>
#include <QFileDialog>
#include <QMessageBox>
#include <QDesktopWidget>


fhf_mainWindow::fhf_mainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::fhf_mainWindow)
{
    ui->setupUi(this);
    ui->splitter->setStretchFactor(1,4);
    adjust_windowGeometry();
    label_connect=new QLabel(this);
    label_freq=new QLabel(this);
    label_tableLen=new QLabel(this);
    label_connect->setFont(QFont("Arial",11,QFont::Bold));
    label_freq->setFont(QFont("Arial",11,QFont::Bold));
    label_tableLen->setFont(QFont("Arial",11,QFont::Bold));
    ui->statusBar->addWidget(label_connect);
    ui->statusBar->addWidget(label_freq);
    ui->statusBar->addWidget(label_tableLen);
    ui->pushButton_chart1->setEnabled(false);
    ui->pushButton_chart2->setEnabled(false);
    set_buttons_disconnected();


    m_contractHash=new QMultiHash<QString,QString>;
    initTree(); initStyle();
    connect(ui->treeWidget,SIGNAL(itemDoubleClicked(QTreeWidgetItem*, int)),
            this,SLOT(onItemDoubleClicked(QTreeWidgetItem*, int)));
    m_timerTcp=new QTimer(this);
    m_timerRefresh=new QTimer(this);
    m_timerTcp->setInterval(200);
    m_timerRefresh->setInterval(50);
    connect(m_timerTcp,SIGNAL(timeout()),this,SLOT(on_tcpTimeout()));
    connect(m_timerRefresh,SIGNAL(timeout()),this,SLOT(on_refreshTimeout()));

    qDebug()<<ui->tableWidget;
    pWorkThread= new WorkThread(ui->tableWidget);
    connect(pWorkThread,SIGNAL(connectFinished()),this,SLOT(onConnectFinished()));
    connect(pWorkThread,SIGNAL(queryContractFinished()),this,SLOT(onQueryContractFinished()));
    connect(pWorkThread,SIGNAL(queryTableFinished()),this,SLOT(on_queryTableFinished()));
    connect(pWorkThread,SIGNAL(queryTableProgress(int, int)),this,SLOT(on_queryTableProgress(int, int)));

    pChartThread =new ChartThread(ui->chartView1,ui->chartView2);
    chartHistogram = new QChart();
    chartMinute = new QChart();
    chartPie = new QChart();
    ui->chartView1->setChart(chartHistogram);
    ui->chartView2->setChart(chartMinute);

    connect(pWorkThread,SIGNAL(signalTick(QDateTime,qreal,int,int,int,int)),
            pChartThread,SLOT(processTick(QDateTime,qreal,int,int,int,int)));
    connect(pWorkThread,SIGNAL(signalBar(QDateTime,int,int)),
            pChartThread,SLOT(processBar(QDateTime,int,int)));

    connect(this,SIGNAL(signalChart(QString,QString,QString)),pChartThread,SLOT(setStatusPlotting(QString,QString,QString)));
    connect(pChartThread,SIGNAL(plottingChartFinished()),this,SLOT(on_plottingChartFinished()));
    connect(this,SIGNAL(signalClearBar()),pChartThread,SLOT(clearBar()));
    connect(this,SIGNAL(signalClearTick()),pChartThread,SLOT(clearTick()));
    connect(pChartThread,SIGNAL(chartMinuteReady()),this,SLOT(plotChartMinute()));
    connect(pChartThread,SIGNAL(chartPieReady()),this,SLOT(plotChartPie()));
    connect(pChartThread,SIGNAL(chartHistogramReady()),this,SLOT(plotChartHistogram()));


    //运行各线程
    pWorkThread->start();
    pChartThread->start();

    ui->plainTextEdit->insertPlainText(QStringLiteral("### 数据公开，欢迎使用 ^_^ 来源于天软科技和掘金量化，非交易所官方资源 ###\n"));
    ui->plainTextEdit->insertPlainText(QStringLiteral("###########        投资有风险，入市必谨慎，祝君顺利          ###############\n\n"));
    this->showMaximized();
}

fhf_mainWindow::~fhf_mainWindow()
{
    delete ui;
}

void fhf_mainWindow::closeEvent(QCloseEvent *event)
{
    auto temp = QMessageBox::information(
                this,
                QStringLiteral("提示"),
                QStringLiteral("是否现在就关闭?"),
                QStringLiteral("确定"),
                QStringLiteral("取消"),
                nullptr, 1
                );
    if (temp == 0)
        event->accept();
    else
        event->ignore();
}

void fhf_mainWindow::initStyle()
{
    //加载样式表
    //QFile file(":/qss/psblack.css");
    QFile file(":/qss/flatwhite.css");
    //QFile file(":/qss/lightblue.css");
    if (file.open(QFile::ReadOnly)) {
        QString qss = QLatin1String(file.readAll());
        QString paletteColor = qss.mid(20, 7);
        qApp->setPalette(QPalette(QColor(paletteColor)));
        qApp->setStyleSheet(qss);
        file.close();
    }
}

void fhf_mainWindow::adjust_windowGeometry()
{
    QDesktopWidget* desktopWidget = QApplication::desktop();
    //获取可用桌面大小
    QRect deskRect = desktopWidget->availableGeometry();
    //获取设备屏幕大小
    QRect screenRect = desktopWidget->screenGeometry();

    int g_nActScreenX = screenRect.width();
    int g_nActScreenY = screenRect.height();
    int deskX = deskRect.width();
    int deskY = deskRect.height();

    int width_1 = int(ui->treeWidget->minimumWidth()*deskX/2560.0);
    ui->treeWidget->setMinimumWidth(width_1);
    int width_2 = int(ui->frame_3->maximumWidth()*deskX/2560.0);
    ui->frame_3->setMaximumWidth(width_2);
    ui->frame_2->setMaximumWidth(width_2);
    ui->frame_2->setMinimumWidth(width_2);
    ui->plainTextEdit->setMinimumWidth(g_nActScreenX-width_1-width_2-35);

    int height_1 = int(ui->frame->minimumHeight()*deskY/1380.0);
    ui->frame->setMinimumHeight(height_1);
    ui->frame->setMaximumHeight(height_1);

    int height;
    height = int(ui->btnConnect->minimumHeight() *deskY/1380.0);
    ui->btnConnect->setMinimumHeight(height);
    height = int(ui->label->minimumHeight() *deskY/1380.0);
    ui->label->setMinimumHeight(height);
    height = int(ui->comboBox->minimumHeight() *deskY/1380.0);
    ui->comboBox->setMinimumHeight(height);
    height = int(ui->btnContracts->minimumHeight() *deskY/1380.0);
    ui->btnContracts->setMinimumHeight(height);
    height = int(ui->line_2->minimumHeight() *deskY/1380.0);
    ui->line_2->setMinimumHeight(height);
    height = int(ui->label_current->minimumHeight() *deskY/1380.0);
    ui->label_current->setMinimumHeight(height);
    height = int(ui->label_2->minimumHeight() *deskY/1380.0);
    ui->label_2->setMinimumHeight(height);
    height = int(ui->dateEdit_beg->minimumHeight() *deskY/1380.0);
    ui->dateEdit_beg->setMinimumHeight(height);
    height = int(ui->label_3->minimumHeight() *deskY/1380.0);
    ui->label_3->setMinimumHeight(height);
    height = int(ui->dateEdit_end->minimumHeight() *deskY/1380.0);
    ui->dateEdit_end->setMinimumHeight(height);
    height = int(ui->btnQuery->minimumHeight() *deskY/1380.0);
    ui->btnQuery->setMinimumHeight(height);
    height = int(ui->label_4->height() *deskY/1380.0);
    ui->label_4->resize(ui->label_4->width(),height );
    height = int(ui->btnFile->minimumHeight() *deskY/1380.0);
    ui->btnFile->setMinimumHeight(height);

    int width=int(ui->label_current->minimumWidth() *deskY/2560.0);
    ui->label_current->setMinimumWidth(qMax(200,width));

    qDebug()<<"Current window_geometry:"<<g_nActScreenX<<g_nActScreenY<<deskX<<deskY;
}

void fhf_mainWindow::testOnly(QTreeWidgetItem *, QTreeWidgetItem *)
{
    qDebug()<<"Hey, test is here_01";
}

void fhf_mainWindow::testOnly()
{
    qDebug()<<"Hey, test is here";
}


void fhf_mainWindow::initTree()
{
    QString dataStr=ui->comboBox->currentText();
    ui->treeWidget->clear();
    QStyle* style = QApplication::style();
    QIcon icon;
    icon=style->standardIcon(QStyle::SP_DriveFDIcon);

    QTreeWidgetItem *item=new QTreeWidgetItem(int(1001));
    item->setIcon(0,icon);
    item->setFlags(Qt::ItemIsSelectable | Qt::ItemIsEnabled | Qt::ItemIsAutoTristate);
    item->setData(0,Qt::DisplayRole,dataStr);
    ui->treeWidget->addTopLevelItem(item);
}

void fhf_mainWindow::set_buttons_disconnected()
{
    ui->btnConnect->setEnabled(true);
    ui->btnContracts->setEnabled(false);
    ui->btnQuery->setEnabled(false);
    ui->label_current->setText(QStringLiteral("当前期货合约：%1 \t\t\t").arg(QStringLiteral("未选择")));
    label_connect->setText(QStringLiteral("服务器状态：未连接 \t\t\t"));
    label_freq->setText(QStringLiteral("数据频率：%1 \t\t\t").arg(ui->comboBox->currentText()));
    label_tableLen->setText(QStringLiteral("总行数：%1 \t\t\t").arg(ui->tableWidget->rowCount()));
}

void fhf_mainWindow::on_btnConnect_clicked()
{
    set_buttons_connecting();
    this->pWorkThread->status=WorkThread::status_connecting;
}

void fhf_mainWindow::set_buttons_connecting()
{
    ui->btnConnect->setEnabled(false);
    ui->btnContracts->setEnabled(false);
    ui->btnQuery->setEnabled(false);
    ui->label_current->setText(QStringLiteral("当前期货合约：%1 \t\t\t").arg(QStringLiteral("未选择")));
    label_connect->setText(QStringLiteral("服务器状态：正在连接 \t\t\t"));
    label_freq->setText(QStringLiteral("数据频率：%1 \t\t\t").arg(ui->comboBox->currentText()));
    label_tableLen->setText(QStringLiteral("总行数：%1 \t\t\t").arg(ui->tableWidget->rowCount()));
}

void fhf_mainWindow::onConnectFinished()
{
    set_buttons_connected();
}

void fhf_mainWindow::set_buttons_connected()
{
    ui->btnConnect->setEnabled(false);
    ui->btnContracts->setEnabled(true);
    ui->btnQuery->setEnabled(false);
    ui->label_current->setText(QStringLiteral("当前期货合约：%1 \t\t\t").arg(QStringLiteral("未选择")));
    label_connect->setText(QStringLiteral("服务器状态：已连接 \t\t\t"));
    label_freq->setText(QStringLiteral("数据频率：%1 \t\t\t").arg(ui->comboBox->currentText()));
    label_tableLen->setText(QStringLiteral("总行数：%1 \t\t\t").arg(ui->tableWidget->rowCount()));
}

void fhf_mainWindow::on_btnContracts_clicked()
{
    initTree();
    set_buttons_queryingContracts();
    pWorkThread->freqStr=ui->comboBox->currentText();
    ui->tableWidget->clear();
    ui->tableWidget->setRowCount(0);
    QStringList header;
    if (pWorkThread->freqStr=="1 min") {
        ui->tableWidget->setColumnCount(8);
        header<<"datetime"<<"open"<<"high"<<"low"
             <<"close"<<"volume"<<"amount"<<"position";
        ui->comboBox_dataItem->clear();
        QStringList itemList;
        itemList<<"volume"<<"pos_change";
        ui->comboBox_dataItem->addItems(itemList);
    } else {
        ui->tableWidget->setColumnCount(12);
        header<<"datetime"<<"price"<<"last_volume"<<"last_amount"
            <<"bid1"<<"bid1_vol"<<"ask1"<<"ask1_vol"
            <<"position"<<"openD"<<"highD"<<"lowD";
        ui->comboBox_dataItem->clear();
        QStringList itemList;
        itemList<<"last_volume"<<"pos_change"<<"bid1_vol"<<"ask1_vol";
        ui->comboBox_dataItem->addItems(itemList);
    }
    ui->tableWidget->setHorizontalHeaderLabels(header);
    pWorkThread->status=WorkThread::status_queryingContracts;
    label_tableLen->setText(QStringLiteral("总行数：%1 \t\t\t").arg(ui->tableWidget->rowCount()));
    set_ChartInvisible();
}

void fhf_mainWindow::set_buttons_queryingContracts()
{
    ui->btnConnect->setEnabled(false);
    ui->btnContracts->setEnabled(false);
    ui->btnQuery->setEnabled(false);
    ui->label_current->setText(QStringLiteral("当前期货合约：%1 \t\t\t").arg(QStringLiteral("未选择")));
    label_connect->setText(QStringLiteral("服务器状态：正在查询合约 \t\t\t"));
    label_freq->setText(QStringLiteral("数据频率：%1 \t\t\t").arg(ui->comboBox->currentText()));
    ui->chartView1->setVisible(false);
    ui->chartView2->setVisible(false);
    ui->pushButton_chart1->setEnabled(false);
    ui->pushButton_chart2->setEnabled(false);
    flag_readyForTextChanged=false;
}

void fhf_mainWindow::onQueryContractFinished()
{
    set_buttons_queryFinished();
    m_contractHash->clear();

    for (quint16 i=0;i<pWorkThread->ContractList.count();i++) {
        QString contract=pWorkThread->ContractList.at(i);
        QString symbol=contract;
        symbol.chop(4);
        m_contractHash->insert(symbol,contract);
    }

    QStringList keys=m_contractHash->keys();
    keys.removeDuplicates(); keys.sort();
    //qDebug()<<keys;

    for (quint16 i=0;i<keys.count();i++) {
        QStyle* style = QApplication::style();
        QIcon icon;
        icon=style->standardIcon(QStyle::SP_DirIcon);

        QTreeWidgetItem *item0=new QTreeWidgetItem(int(1002));
        item0->setIcon(0,icon);
        item0->setFlags(Qt::ItemIsSelectable | Qt::ItemIsEnabled | Qt::ItemIsAutoTristate);
        item0->setData(0,Qt::DisplayRole,keys.at(i));
        ui->treeWidget->topLevelItem(0)->addChild(item0);

        QList<QString> contracts;
        contracts=m_contractHash->values(keys.at(i)); contracts.sort();

        for (quint16 j=0;j<contracts.count();j++) {
            QStyle* style = QApplication::style();
            QIcon icon1;
            icon1=style->standardIcon(QStyle::SP_FileDialogDetailedView);

            QTreeWidgetItem *item1=new QTreeWidgetItem(int(1003));
            item1->setIcon(0,icon1);
            item1->setFlags(Qt::ItemIsSelectable | Qt::ItemIsEnabled | Qt::ItemIsAutoTristate);
            item1->setData(0,Qt::DisplayRole,contracts.at(j));
            item0->addChild(item1);
        }
    }
    ui->treeWidget->topLevelItem(0)->setExpanded(true);
    //qDebug()<<ui->treeWidget->headerItem()->text(0);
}

void fhf_mainWindow::set_buttons_queryFinished()
{
    ui->btnConnect->setEnabled(false);
    ui->btnContracts->setEnabled(true);
    ui->btnQuery->setEnabled(true);
    ui->btnQuery->setText(QStringLiteral("查询合约数据"));
    ui->btnFile->setEnabled(true);
    label_connect->setText(QStringLiteral("服务器状态：已连接 \t\t\t"));
    label_tableLen->setText(QStringLiteral("总行数：%1 \t\t\t").arg(ui->tableWidget->rowCount()));
    ui->pushButton_chart1->setEnabled(false);
    ui->pushButton_chart2->setEnabled(false);
}

void fhf_mainWindow::onItemDoubleClicked(QTreeWidgetItem *item, int )
{
    if (item->type()==1003) {
        ui->label_current->setText(QStringLiteral("当前期货合约：%1 \t\t\t").arg(item->text(0)));
        pWorkThread->curContract=item->text(0);
    }
}

void fhf_mainWindow::on_btnQuery_clicked()
{
    if (ui->label_current->text()==QStringLiteral("当前期货合约：未选择 \t\t\t"))
        return;

    set_buttons_queryingTable();
    if (ui->btnQuery->text()==QStringLiteral("查询合约数据")) {
        ui->btnQuery->setText(QStringLiteral("停止"));
        set_ChartInvisible();
        if (pWorkThread->freqStr=="1 min")
            emit signalClearBar();
        else
            emit signalClearTick();
        pWorkThread->pTable->setRowCount(0);
        for (quint16 i=0;i<ui->tableWidget->columnCount();i++)
            ui->tableWidget->setColumnHidden(i,true);
        bytesToSend=2000000;
        pWorkThread->set_bytesTotal(bytesToSend);
        pWorkThread->set_bytesRemaining(bytesToSend);
        pWorkThread->status=WorkThread::status_queryingTable;
        m_timerTcp->start();
        m_timerRefresh->start();
        QString string=QStringLiteral("正在查询数据：%1").arg(pWorkThread->curContract);
        ui->plainTextEdit->insertPlainText(string+"\n");
        label_tableLen->setText(QStringLiteral("总行数：%1 \t\t\t").arg(ui->tableWidget->rowCount()));
    } else if (ui->btnQuery->text()==QStringLiteral("停止")) {
        ui->btnQuery->setText(QStringLiteral("正在停止"));
        ui->btnQuery->setEnabled(false);
        m_timerTcp->stop();
        pWorkThread->set_bytesRemaining(0);
        QString string=QStringLiteral("正在停止查询：%1").arg(pWorkThread->curContract);
        ui->plainTextEdit->insertPlainText(string+"\n");
    }
}

void fhf_mainWindow::set_buttons_queryingTable()
{
    ui->btnConnect->setEnabled(false);
    ui->btnContracts->setEnabled(false);
    ui->btnFile->setEnabled(false);
    label_connect->setText(QStringLiteral("服务器状态：正在查询数据 \t\t\t"));
    label_freq->setText(QStringLiteral("数据频率：%1 \t\t\t").arg(ui->comboBox->currentText()));
    label_tableLen->setText(QStringLiteral("总行数：%1 \t\t\t").arg(ui->tableWidget->rowCount()));
    ui->chartView1->setVisible(false);
    ui->chartView2->setVisible(false);
    ui->pushButton_chart1->setEnabled(false);
    ui->pushButton_chart2->setEnabled(false);
}

void fhf_mainWindow::on_tcpTimeout()
{
    # define BLOCK_SIZE 1000
    bytesToSend-=BLOCK_SIZE;
    if (bytesToSend==0)
        m_timerTcp->stop();
    pWorkThread->bytesAvailable+=BLOCK_SIZE;
    //qDebug()<<"tcp timeout! bytesToSend: "<<bytesToSend;
}

void fhf_mainWindow::on_refreshTimeout()
{
    pWorkThread->flagRefresh=true;
    //qDebug()<<"refresh timeout!";
}

void fhf_mainWindow::on_queryTableProgress(int count, int total)
{
    QString string;
    string=QStringLiteral("下载进度： 已下载/总数据 = %1/%2")
            .arg(QString::number(count))
            .arg(QString::number(total));
    ui->plainTextEdit->insertPlainText(string+"\n");
    label_tableLen->setText(QStringLiteral("总行数：%1 \t\t\t").arg(ui->tableWidget->rowCount()));
}

void fhf_mainWindow::on_queryTableFinished()
{
    //set_buttons_queryFinished();
    m_timerRefresh->stop();
    //ui->tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
    for (quint16 i=0;i<ui->tableWidget->columnCount();i++)
        ui->tableWidget->setColumnHidden(i,false);
    QString string=QStringLiteral("数据查询结束：%1\n").arg(pWorkThread->curContract);
    ui->plainTextEdit->insertPlainText(string+"\n");
    emit signalChart(
        pWorkThread->freqStr,
        ui->comboBox_dataItem->currentText(),
        ui->comboBox_dayNight->currentText()
    );
    qDebug()<<"Query table finished!";
}

void fhf_mainWindow::on_btnFile_clicked()
{
    //获取创建的csv文件名
    QString fileName = QFileDialog::getSaveFileName(this, tr("csv file"), qApp->applicationDirPath (),tr("Files (*.csv)"));
    if (fileName.isEmpty()) return;
    //打开.csv文件
    QFile file(fileName);
    if(!file.open(QIODevice::WriteOnly | QIODevice::Text))  {
        qDebug()<< "Cannot open file for writing: "<<qPrintable(file.errorString());
        QMessageBox::information(this,
            QStringLiteral("导出失败！"),
            QStringLiteral("错误原因：%1").arg(file.errorString()),
            QStringLiteral("确定")
        );
        file.close();
        return;
    }
    else {
        //获取数据
        QTextStream out(&file);
        for (quint16 i=0;i<ui->tableWidget->columnCount(); i++)
            out << (ui->tableWidget->horizontalHeaderItem(i)->text()+",") ;//表头
        out<<"\n";
        QList<int> values;
        values<<1<<2<<3<<4<<5;
        //获取表格内容
        for(int row = 0; row < ui->tableWidget->rowCount(); row++) {
            for(int col=0; col<ui->tableWidget->columnCount(); col++) {
                QString string;
                string=ui->tableWidget->item(row,col)->text();
                out << string << ",";// 写入文件
            }
            out << "\n";
        }
        QMessageBox::information(this,
            QStringLiteral("导出数据成功"),
            QStringLiteral("数据已保存在 %1！").arg(fileName),
            QStringLiteral("确定")
        );
        file.close();
    }
}

void fhf_mainWindow::set_ChartInvisible()
{
    ui->label_mean->setText("-");
    ui->label_std->setText("-");
    ui->label_medium->setText("-");

    ui->label_d25->setText("-");
    ui->label_d50->setText("-");
    ui->label_d75->setText("-");
    ui->label_d90->setText("-");
    ui->label_d95->setText("-");

    ui->pushButton_chart1->setEnabled(false);
    ui->pushButton_chart2->setEnabled(false);
    ui->chartView1->setVisible(false);
    ui->chartView2->setVisible(false);
    flag_readyForTextChanged=false;
}

void fhf_mainWindow::on_plottingChartFinished()
{
    set_buttons_queryFinished();
    set_ChartVisible();
    qDebug()<<"slot_plottingFinished";
}

void fhf_mainWindow::set_ChartVisible()
{
    ui->label_mean->setText(pChartThread->str_mean);
    ui->label_std->setText(pChartThread->str_std);
    ui->label_medium->setText(pChartThread->str_medium);

    ui->label_d25->setText(pChartThread->str_d25);
    ui->label_d50->setText(pChartThread->str_d50);
    ui->label_d75->setText(pChartThread->str_d75);
    ui->label_d90->setText(pChartThread->str_d90);
    ui->label_d95->setText(pChartThread->str_d95);

    if (pChartThread->str_mean!="nan") {
        ui->chartView1->setVisible(true);
        ui->chartView2->setVisible(true);
        ui->pushButton_chart1->setEnabled(true);
        ui->pushButton_chart2->setEnabled(true);
    } else {
        ui->chartView1->setVisible(false);
        ui->chartView2->setVisible(false);
        ui->pushButton_chart1->setEnabled(false);
        ui->pushButton_chart2->setEnabled(false);
    }

    flag_readyForTextChanged=true;
}

void fhf_mainWindow::on_comboBox_dataItem_currentTextChanged(const QString &)
{
    if (flag_readyForTextChanged) {
        set_ChartInvisible();
        emit signalChart(
            pWorkThread->freqStr,
            ui->comboBox_dataItem->currentText(),
            ui->comboBox_dayNight->currentText()
        );
        qDebug()<<"################# on_dataItem_TextChange";
    }
}

void fhf_mainWindow::on_comboBox_dayNight_currentTextChanged(const QString &)
{
    if (flag_readyForTextChanged) {
        set_ChartInvisible();
        emit signalChart(
            pWorkThread->freqStr,
            ui->comboBox_dataItem->currentText(),
            ui->comboBox_dayNight->currentText()
        );
        qDebug()<<"################# on_dayNight_TextChange";
    }
}

void fhf_mainWindow::plotChartMinute()
{
    ui->chartView2->setVisible(false);
    chartMinute->removeAllSeries();
    chartMinute->removeAxis(chartMinute->axisX());
    chartMinute->removeAxis(chartMinute->axisY());

    if (pChartThread->chartMinute_xAxis.count()>0) {
        QBarSet *minuteSet=new QBarSet(
            QStringLiteral("前30分钟 - %1平均值")
            .arg(ui->comboBox_dataItem->currentText())
        );
        for (int i=0;i<30;i++) {
            minuteSet->append(pChartThread->chartMinute_yAxis.at(i));
        }

        QBarSeries *series = new QBarSeries();
        series->append(minuteSet);
        chartMinute->addSeries(series);

        QStringList categories;
        for (int i=0; i<30;i++)
            categories.append(pChartThread->chartMinute_xAxis.at(i));

        QBarCategoryAxis *xAxis = new QBarCategoryAxis();
        xAxis->append(categories);
        xAxis->setRange(categories.first(),categories.last());
        xAxis->setLabelsVisible(false);
        xAxis->setGridLineVisible(false);
        chartMinute->setAxisX(xAxis,series);

        QValueAxis *yAxis = new QValueAxis();
        QList<qreal> values=pChartThread->chartMinute_yAxis;
        std::sort(values.begin(),values.end());
        qreal x1=values.first();
        qreal x2=values.last();
        yAxis->setRange(x1,x2);
        yAxis->setTickCount(5);
        yAxis->setGridLineVisible(false);
        chartMinute->setAxisY(yAxis,series);

        chartMinute->legend()->setVisible(true);
        chartMinute->setVisible(true);
        ui->chartView2->setChart(chartMinute);

        //qDebug()<<categories<<minuteSet;
    }

    qDebug()<<"fhf_mainWindow: plotChartMinute finished!";
}


void fhf_mainWindow::plotChartPie()
{
    ui->chartView2->setVisible(false);
    chartPie->removeAllSeries();

    if (pChartThread->tradeTypeList.count()>0) {
        QPieSeries *series= new QPieSeries();
        series->setHoleSize(0);
        series->setPieSize(1);
        for (quint16 i=0; i<8; i++) {
            series->append(pChartThread->tradeTypeNames.at(i),pChartThread->tradeTypeCounts.at(i));
        }
        series->setVisible(true);
        chartPie->setVisible(true);
        chartPie->addSeries(series);
        chartPie->legend()->setVisible(true);
        chartPie->legend()->setAlignment(Qt::AlignRight);
        ui->chartView2->setChart(chartPie);
    }

    qDebug()<<"fhf_mainWindow: plotChartPie finished!";
}


void fhf_mainWindow::plotChartHistogram()
{
    ui->chartView1->setVisible(false);
    chartHistogram->removeAllSeries();
    chartHistogram->removeAxis(chartHistogram->axisX());
    chartHistogram->removeAxis(chartHistogram->axisY());

    if (pChartThread->chartHistogram_xAxis.count()>0) {
        QBarSet *countSet=new QBarSet(
            QStringLiteral("频数分布直方图 - %1")
            .arg(ui->comboBox_dataItem->currentText())
        );
        for (int i=0;i<pChartThread->chartHistogram_xAxis.count();i++) {
            countSet->append(pChartThread->chartHistogram_yAxis.at(i));
        }

        QBarSeries *series = new QBarSeries();
        series->append(countSet);
        chartHistogram->addSeries(series);

        QStringList categories;
        for (int i=0; i<pChartThread->chartHistogram_xAxis.count();i++)
            categories.append(pChartThread->chartHistogram_xAxis.at(i));

        QBarCategoryAxis *xAxis = new QBarCategoryAxis();
        xAxis->append(categories);
        xAxis->setRange(categories.first(),categories.last());
        xAxis->setLabelsVisible(false);
        xAxis->setGridLineVisible(false);
        chartHistogram->setAxisX(xAxis,series);

        QValueAxis *yAxis = new QValueAxis();
        QList<int> values=pChartThread->chartHistogram_yAxis;
        std::sort(values.begin(),values.end());
        qreal x1=values.first();
        qreal x2=values.last();
        yAxis->setRange(x1,x2);
        yAxis->setTickCount(5);
        yAxis->setGridLineVisible(false);
        yAxis->setLabelFormat("%d");
        chartHistogram->setAxisY(yAxis,series);

        chartHistogram->legend()->setVisible(true);
        chartHistogram->setVisible(true);
        ui->chartView1->setChart(chartHistogram);

        //qDebug()<<categories<<countSet;
    }

    qDebug()<<"fhf_mainWindow: plotchartHistogram finished!";
}

void fhf_mainWindow::on_pushButton_chart1_clicked()
{
    //获取创建的csv文件名
    QString fileName = QFileDialog::getSaveFileName(this, tr("csv file"), qApp->applicationDirPath (),tr("Files (*.csv)"));
    if (fileName.isEmpty()) return;
    //打开.csv文件
    QFile file(fileName);
    if(!file.open(QIODevice::WriteOnly | QIODevice::Text))  {
        qDebug()<< "Cannot open file for writing: "<<qPrintable(file.errorString());
        QMessageBox::information(this,
            QStringLiteral("导出失败！"),
            QStringLiteral("错误原因：%1").arg(file.errorString()),
            QStringLiteral("确定")
        );
        file.close();
        return;
    }
    else {
        //获取数据
        QTextStream out(&file);
        //表头
        out << "Data_interval: " <<ui->comboBox_dataItem->currentText() << ",";
        out << "Frequency: " << ui->comboBox_dataItem->currentText() << "," ;
        out<<"\n";
        //获取表格内容
        for(int row = 0; row < pChartThread->chartHistogram_xAxis.count(); row++) {
            // 写入文件
            out << pChartThread->chartHistogram_xAxis.at(row) << ","
                << pChartThread->chartHistogram_yAxis.at(row) <<",";
            out << "\n";
        }
        QMessageBox::information(this,
            QStringLiteral("导出数据成功"),
            QStringLiteral("数据已保存在 %1！").arg(fileName),
            QStringLiteral("确定")
        );
        file.close();
    }

}

void fhf_mainWindow::on_pushButton_chart2_clicked()
{
    if (pWorkThread->freqStr=="1 min") {
        exportChartMinute();
    } else {
        exportChartPie();
    }
}

void fhf_mainWindow::exportChartMinute() {
    //获取创建的csv文件名
    QString fileName = QFileDialog::getSaveFileName(this, tr("csv file"), qApp->applicationDirPath (),tr("Files (*.csv)"));
    if (fileName.isEmpty()) return;
    //打开.csv文件
    QFile file(fileName);
    if(!file.open(QIODevice::WriteOnly | QIODevice::Text))  {
        qDebug()<< "Cannot open file for writing: "<<qPrintable(file.errorString());
        QMessageBox::information(this,
            QStringLiteral("导出失败！"),
            QStringLiteral("错误原因：%1").arg(file.errorString()),
            QStringLiteral("确定")
        );
        file.close();
        return;
    }
    else {
        //获取数据
        QTextStream out(&file);
        //表头
        out << "minute_eachDay" << ",";
        out << "meanValue: " << ui->comboBox_dataItem->currentText() << "," ;
        out<<"\n";
        //获取表格内容
        for(int row = 0; row < pChartThread->chartMinute_xAxis.count(); row++) {
            // 写入文件
            out << pChartThread->chartMinute_xAxis.at(row) << ","
                << pChartThread->chartMinute_yAxis.at(row) <<",";
            out << "\n";
        }
        QMessageBox::information(this,
            QStringLiteral("导出数据成功"),
            QStringLiteral("数据已保存在 %1！").arg(fileName),
            QStringLiteral("确定")
        );
        file.close();
    }

    qDebug()<<"fhf_mainWindow has exported ChartMinute";
}

void fhf_mainWindow::exportChartPie() {
    //获取创建的csv文件名
    QString fileName = QFileDialog::getSaveFileName(this, tr("csv file"), qApp->applicationDirPath (),tr("Files (*.csv)"));
    if (fileName.isEmpty()) return;
    //打开.csv文件
    QFile file(fileName);
    if(!file.open(QIODevice::WriteOnly | QIODevice::Text))  {
        qDebug()<< "Cannot open file for writing: "<<qPrintable(file.errorString());
        QMessageBox::information(this,
            QStringLiteral("导出失败！"),
            QStringLiteral("错误原因：%1").arg(file.errorString()),
            QStringLiteral("确定")
        );
        file.close();
        return;
    }
    else {
        //获取数据
        QTextStream out(&file);
        //表头
        out << "trade_type" << ",";
        out << "trade_count" << "," ;
        out<<"\n";

        //获取表格内容
        QStringList tradeTypeUtf8;
        tradeTypeUtf8
        <<QStringLiteral("ShuangKai")
        <<QStringLiteral("ShuangPing")
        <<QStringLiteral("DuoKai")
        <<QStringLiteral("KongKai")
        <<QStringLiteral("KongPing")
        <<QStringLiteral("DuoPing")
        <<QStringLiteral("DuoHuan")
        <<QStringLiteral("KongHuan");

        for(int row = 0; row < pChartThread->tradeTypeNames.count(); row++) {
            // 写入文件
            out << tradeTypeUtf8.at(row) << ","
                << pChartThread->tradeTypeCounts.at(row) <<",";
            out << "\n";
        }
        QMessageBox::information(this,
            QStringLiteral("导出数据成功"),
            QStringLiteral("数据已保存在 %1！").arg(fileName),
            QStringLiteral("确定")
        );
        file.close();
    }

    qDebug()<<"fhf_mainWindow has exported ChartPie";
}

